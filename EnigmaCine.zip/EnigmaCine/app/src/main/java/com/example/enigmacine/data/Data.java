package com.example.enigmacine.data;

public class Data {

    private String film;
    private String date;
    private String hour;
    private String note;
    private String real;
    private String music;
    private String review;

    public Data(String film, String date, String hour, String note, String real, String music, String review) {
        this.film = film;
        this.date = date;
        this.hour = hour;
        this.note = note;
        this.real = real;
        this.music = music;
        this.review = review;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getReal() {
        return real;
    }

    public void setReal(String real) {
        this.real = real;
    }

    public String getMusic() {
        return music;
    }

    public void setMusic(String music) {
        this.music = music;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getFilm() {
        return film;
    }

    public void setFilm(String film) {
        this.film = film;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
