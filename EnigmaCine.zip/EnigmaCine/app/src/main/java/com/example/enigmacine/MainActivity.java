package com.example.enigmacine;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.enigmacine.data.Data;
import com.example.enigmacine.data.DbHelper;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btn_film;
    EditText et_film;
    EditText et_date;
    EditText et_hour;
    EditText et_note;
    EditText et_real;
    EditText et_music;
    EditText et_review;

    String etable_film;
    String etable_date;
    String etable_hour;
    String etable_note;
    String etable_real;
    String etable_music;
    String etable_review;

    private DbHelper dbHelper;


    EditText et_mail;
    EditText et_object;
    Button btn_mail;
    String st_mail;
    String st_object;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DbHelper(getApplicationContext());

        btn_film = (Button) findViewById(R.id.btn_film);
        btn_film.setOnClickListener(this);
        et_film = (EditText) findViewById(R.id.et_film);
        et_date = (EditText) findViewById(R.id.et_date);
        et_hour = (EditText) findViewById(R.id.et_hour);
        et_note = (EditText) findViewById(R.id.et_note);
        et_real = (EditText) findViewById(R.id.et_real);
        et_music = (EditText) findViewById(R.id.et_music);
        et_review = (EditText) findViewById(R.id.et_review);

        et_mail = (EditText) findViewById(R.id.et_mail);
        et_object = (EditText) findViewById(R.id.et_object);
        btn_mail = (Button) findViewById(R.id.btn_mail);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_film:
                etable_film = et_film.getText().toString();
                etable_date = et_date.getText().toString();
                etable_hour = et_hour.getText().toString();
                etable_note = et_note.getText().toString();
                etable_real = et_real.getText().toString();
                etable_music = et_music.getText().toString();
                etable_review = et_review.getText().toString();
                addToContract(v);
                break;
            case R.id.btn_mail:
                st_mail = et_mail.getText().toString();
                st_object = et_object.getText().toString();
                sendMail(v);
        }


    }

    public void addToContract(View v){
        if (et_film.getText().length() == 0 || et_date.getText().length() == 0 || et_hour.getText().length() == 0
                || et_note.getText().length() == 0 || et_real.getText().length() == 0 ||
                et_music.getText().length() == 0 || et_review.getText().length() == 0 )
        {
            return;
        }

        dbHelper.insertData(new Data(etable_film, etable_date,etable_hour,etable_note,etable_real,etable_music,etable_review));
    }

    public void sendMail(View v){
        if(et_mail.getText().length() == 0 || et_object.getText().length() == 0){
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW
                , Uri.parse("mailto:" + st_mail));
        intent.putExtra(Intent.EXTRA_SUBJECT, st_object);
        intent.putExtra(Intent.EXTRA_TEXT, new String[] {
                et_film.getText().toString(),
                et_date.getText().toString(),
                et_hour.getText().toString(),
                et_note.getText().toString(),
                et_real.getText().toString(),
                et_music.getText().toString(),
                et_review.getText().toString()});
        startActivity(intent);
    }
}