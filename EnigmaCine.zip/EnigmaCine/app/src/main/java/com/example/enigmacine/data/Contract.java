package com.example.enigmacine.data;

import android.provider.BaseColumns;

public class Contract {

    public static final class ContractEntry implements BaseColumns {

        public static final String TABLE_NAME = "filmReviews";

        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_NAME = "filmName";
        public static final String COLUMN_DATE = "filmDate";
        public static final String COLUMN_HOUR = "filmHour";
        public static final String COLUMN_NOTE = "filmNote";
        public static final String COLUMN_REAL = "filmReal";
        public static final String COLUMN_MUSIC = "filmMusic";
        public static final String COLUMN_REVIEW = "filmReview";
    }

}
