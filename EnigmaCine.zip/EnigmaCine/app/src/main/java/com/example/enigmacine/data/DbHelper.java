package com.example.enigmacine.data;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    private static final String TAG = "Data Update !";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final String DATABASE_NAME = "film";

    private static final int DATABASE_VERSION = 1;

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        final String SQL_CREATE_REVIEWS_TABLE = "CREATE TABLE " + Contract.ContractEntry.TABLE_NAME +" (" +
                Contract.ContractEntry. _ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                Contract.ContractEntry. COLUMN_NAME + " TEXT NOT NULL," +
                Contract.ContractEntry. COLUMN_DATE + " DATE NOT NULL," +
                Contract.ContractEntry. COLUMN_HOUR + " TEXT NOT NULL," +
                Contract.ContractEntry. COLUMN_NOTE + " INTEGER NOT NULL," +
                Contract.ContractEntry. COLUMN_REAL + " INTEGER NOT NULL," +
                Contract.ContractEntry. COLUMN_MUSIC + " INTEGER NOT NULL," +
                Contract.ContractEntry. COLUMN_REVIEW + " TEXT NOT NULL" +
                ")";
        sqLiteDatabase.execSQL((SQL_CREATE_REVIEWS_TABLE));
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.ContractEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public void insertData (Data data){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("filmName", data.getFilm());
        contentValues.put("filmDate", data.getDate());
        contentValues.put("filmHour", data.getHour());
        contentValues.put("filmNote", data.getNote());
        contentValues.put("filmReal", data.getReal());
        contentValues.put("filmMusic", data.getMusic());
        contentValues.put("filmReview", data.getReview());
        long mytable = sqLiteDatabase.insert("filmReviews", null, contentValues);
        Log.e(TAG, "insertData: "+mytable);
    }
}
